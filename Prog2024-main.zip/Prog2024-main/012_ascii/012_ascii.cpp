﻿#include <stdio.h>

int main()
{
	printf("%c %d %x\n", '2', '2', '2');
	printf("%c + %c = %c\n", '2', '3', '2' + '3');
	printf("%c = %d = %x", '2' + '3', '2' + '3', '2' + '3'); 
}