﻿#include <stdio.h>

int main()
{
	int a = 3.14;
	float b = 10;

	printf("a=%d, b=%f\n", a, b);
}