﻿#include <stdio.h>

int main()
{
	int a = 30, b = 50;

	bool p = a > b;
	bool q = a < b;
	bool r = a == b;

	printf("%d %d %d\n", p, q, r);
}