﻿// 002_name.cpp : 자신의 학과, 학번, 이름을 출력하세요
//

#include <stdio.h>

int main()
{
    printf("의료IT공학과 24615001 강병익\n");
}
