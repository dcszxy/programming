﻿#include <stdio.h>

int main()
{
    printf("동해물과 백두산이\n마르고\n닳도록");
}
